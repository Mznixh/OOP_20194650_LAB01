import java.util.Scanner;
public class DaysInMonth {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int year;
        String monthInput;
        int monthNumber = 0;

        while (true) {
            System.out.print("Enter a valid year (e.g., 1999): ");
            year = scanner.nextInt();
            if (year > 0) {
                break;
            } else {
                System.out.println("Invalid year. Please enter a non-negative number.");
            }
        }

        scanner.nextLine();

        while (true) {
            System.out.print("Enter a valid month (e.g., January, Jan., Jan, or 1): ");
            monthInput = scanner.nextLine().trim().toLowerCase();

            switch (monthInput) {
                case "january":
                case "jan.":
                case "jan":
                case "1":
                    monthNumber = 1;
                    break;
                case "february":
                case "feb.":
                case "feb":
                case "2":
                    monthNumber = 2;
                    break;
                case "march":
                case "mar.":
                case "mar":
                case "3":
                    monthNumber = 3;
                    break;
                case "april":
                case "apr.":
                case "apr":
                case "4":
                    monthNumber = 4;
                    break;
                case "may":
                case "5":
                    monthNumber = 5;
                    break;
                case "june":
                case "jun":
                case "6":
                    monthNumber = 6;
                    break;
                case "july":
                case "jul":
                case "7":
                    monthNumber = 7;
                    break;
                case "august":
                case "aug.":
                case "aug":
                case "8":
                    monthNumber = 8;
                    break;
                case "september":
                case "sep.":
                case "sep":
                case "9":
                    monthNumber = 9;
                    break;
                case "october":
                case "oct.":
                case "oct":
                case "10":
                    monthNumber = 10;
                    break;
                case "november":
                case "nov.":
                case "nov":
                case "11":
                    monthNumber = 11;
                    break;
                case "december":
                case "dec.":
                case "dec":
                case "12":
                    monthNumber = 12;
                    break;
                default:
                    System.out.println("Invalid month input. Please try again.");
                    continue;
            }
            break;
        }

        boolean isLeapYear = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);

        int daysInMonth;
        switch (monthNumber) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                daysInMonth = 31;
                break;
            case 4: case 6: case 9: case 11:
                daysInMonth = 30;
                break;
            case 2:
                daysInMonth = isLeapYear ? 29 : 28;
                break;
            default:
                daysInMonth = 0;
        }

        System.out.println("The month has " + daysInMonth + " days in the year " + year + ".");
        scanner.close();
    }
}
